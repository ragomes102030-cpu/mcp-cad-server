# -*- coding: utf-8 -*-
"""Seleção e ciclo de vida do backend CAD.

- mode=auto  -> tenta AutoCAD vivo (file_ipc); se não achar a janela, cai para ezdxf headless
- mode=autocad -> exige AutoCAD rodando com a ponte LISP carregada
- mode=ezdxf -> sempre headless (não precisa de AutoCAD nem licença)
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

# o pacote vendorizado mora em src/autocad_mcp
_SRC = Path(__file__).resolve().parents[1]
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from autocad_mcp.backends.ezdxf_backend import EzdxfBackend  # noqa: E402

FileIPCBackend = None
find_autocad_window = None
try:  # só existe no Windows e com pywin32 instalado
    from autocad_mcp.backends.file_ipc import FileIPCBackend, find_autocad_window  # noqa: E402
except Exception:  # pragma: no cover
    pass


class BackendManager:
    """Mantém um backend único, inicializado sob demanda."""

    def __init__(self, mode: str | None = None) -> None:
        self.mode = (mode or os.getenv("CAD_MCP_BACKEND", "auto")).lower()
        self._backend = None

    # ------------------------------------------------------------------
    def _resolve(self):
        if self.mode == "ezdxf":
            return EzdxfBackend(), "ezdxf (forçado)"

        # 1) COM/ActiveX: motor preferido quando o AutoCAD esta aberto.
        #    Nao rouba foco, nao depende de janela nem de PostMessage.
        if self.mode in ("auto", "com", "autocad"):
            try:
                from .com_backend import ComBackend

                b = ComBackend()
                b._conectar(tentativas=2)
                return b, "com (AutoCAD já aberto)"
            except Exception as e:
                if self.mode == "com":
                    raise RuntimeError("backend COM indisponível: %s" % e)

        # 2) Ponte LISP por arquivo (funciona no AutoCAD LT, exige a janela visivel)
        if self.mode in ("auto", "autocad", "file_ipc") and FileIPCBackend is not None:
            from . import win32_bridge

            win32_bridge.patch_vendored()
            hwnd = win32_bridge.find_autocad_window()
            if hwnd:
                return FileIPCBackend(), f"file_ipc (AutoCAD hwnd={hwnd})"

        if self.mode == "autocad":
            raise RuntimeError(
                "AutoCAD nao encontrado: nem via COM (GetActiveObject) nem por janela. "
                "Abra o AutoCAD uma vez e tente de novo."
            )
        return EzdxfBackend(), "ezdxf (headless, sem AutoCAD aberto)"

    async def get(self):
        if self._backend is None:
            self._backend, self._motivo = self._resolve()
            await self._backend.initialize()
        return self._backend

    async def status(self) -> dict:
        b = await self.get()
        st = await b.status()
        return {
            "backend": b.name,
            "selecao": getattr(self, "_motivo", "?"),
            "modo_configurado": self.mode,
            "capabilities": vars(b.capabilities),
            "status": st.to_dict(),
        }

    async def reset(self) -> None:
        self._backend = None


MANAGER = BackendManager()
