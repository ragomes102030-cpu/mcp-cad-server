# -*- coding: utf-8 -*-
"""Ferramentas do mcp-cad-server (lógica pura, sem MCP).

Cada função aqui é registrada como tool no server.py. Nomes compatíveis com o
contrato que o usuário já usa no CADCraft (inspect_drawing, query_entities,
command_line, script, new_drawing, open, save, cancel) + extras nossos
(desenho de planta, padrão de camadas e quantitativo).
"""
from __future__ import annotations

import ctypes
import os
import tempfile
from pathlib import Path

from .backend_manager import MANAGER
from .layers import ensure_standard_layers as _ensure_layers
from .quantitativo import analisar


def _r(res) -> dict:
    """Desembrulha CommandResult em dict simples para o agente."""
    return res.to_dict() if hasattr(res, "to_dict") else {"ok": bool(res), "payload": res}


async def _b():
    return await MANAGER.get()


def _escape_lisp(s: str) -> str:
    return s.replace("\\", "\\\\").replace('"', '\\"')


# --------------------------------------------------------------------- status
async def cad_status() -> dict:
    """Qual motor está ativo (AutoCAD vivo ou headless) e o que ele suporta."""
    return await MANAGER.status()


# ------------------------------------------------------------------ leitura
async def inspect_drawing() -> dict:
    """Estado do desenho: variáveis, contagem de entidades e camadas."""
    b = await _b()
    info = await b.drawing_info()
    vars_ = await b.drawing_get_variables(None)
    cont = await b.entity_count()
    lays = await b.layer_list()
    return {"drawing": _r(info), "variables": _r(vars_),
            "entity_count": _r(cont), "layers": _r(lays)}


async def query_entities(layer: str | None = None, tipo: str | None = None) -> dict:
    """Lista entidades, com filtro opcional por camada e por tipo DXF (LINE, TEXT, ARC, LWPOLYLINE...).

    Cada item traz: handle, tipo, objeto (nome COM), camada. Use o handle no erase.
    """
    return _r(await (await _b()).entity_list(layer=layer, tipo=tipo))


async def erase(entity_id: str) -> dict:
    """Apaga UMA entidade pelo handle (ex.: o handle devolvido por query_entities)."""
    return _r(await (await _b()).entity_erase(entity_id))


async def erase_filter(layer: str | None = None, tipo: str | None = None,
                       texto: str | None = None, confirmar: bool = False) -> dict:
    """Apaga em bloco por camada / tipo DXF / conteudo exato de texto.

    Sem `confirmar=True` apenas CONTA quantos seriam apagados (pre-visualizacao).
    Recusa rodar sem nenhum filtro, para nao apagar o desenho inteiro.
    """
    return _r(await (await _b()).entity_erase_filter(layer=layer, tipo=tipo,
                                                     texto=texto, confirmar=confirmar))


async def move_entity(entity_id: str, dx: float, dy: float) -> dict:
    """Move uma entidade pelo handle, em metros."""
    return _r(await (await _b()).entity_move(entity_id, dx, dy))


async def layer_list() -> dict:
    """Lista as camadas do desenho."""
    return _r(await (await _b()).layer_list())


async def block_list() -> dict:
    """Lista os blocos definidos no desenho."""
    return _r(await (await _b()).block_list())


# ------------------------------------------------------------- comandos CAD
async def command_line(text: str) -> dict:
    """Executa UM comando do AutoCAD (ex.: 'LINE 0,0 10,0 10,5 C').

    Vai pelo backend (COM ou accoreconsole), que ESPERA o comando acabar.
    Nao use a ponte .NET aqui: o `exec` dela e assincrono e nao devolve se o
    comando cortou alguma coisa - bom para pingar, ruim para decidir.

    Pontos com virgula viram coordenada; espaco separa argumentos.
    """
    b = await _b()
    return _r(await b.execute_lisp(f'(command "{_escape_lisp(text)}")'))


async def script(linhas: list[str]) -> dict:
    """Executa vários comandos em sequência."""
    resultados, falhas = [], 0
    for ln in linhas:
        r = await command_line(ln)
        resultados.append(r)
        if not r.get("ok"):
            falhas += 1
    return {"ok": falhas == 0, "executados": len(linhas), "falhas": falhas, "resultados": resultados}


async def cancel() -> dict:
    """Envia ESC ao AutoCAD (cancela comando em execução / limpa seleção)."""
    b = await _b()
    if b.name != "file_ipc":
        return {"ok": False, "erro": "cancel só se aplica com AutoCAD aberto"}
    try:
        target = getattr(b, "_command_hwnd", None) or getattr(b, "_hwnd", None)
        VK_ESCAPE, WM_KEYDOWN, WM_KEYUP = 0x1B, 0x0100, 0x0101
        post = ctypes.windll.user32.PostMessageW
        post(target, WM_KEYDOWN, VK_ESCAPE, 0)
        post(target, WM_KEYUP, VK_ESCAPE, 0)
        return {"ok": True, "acao": "ESC enviado ao AutoCAD"}
    except Exception as exc:
        return {"ok": False, "erro": str(exc)}


# ------------------------------------------------------------- arquivo
async def new_drawing(name: str | None = None) -> dict:
    """Cria um desenho novo."""
    return _r(await (await _b()).drawing_create(name=name))


async def open(path: str) -> dict:
    """Abre um DXF/DWG existente."""
    return _r(await (await _b()).drawing_open(path))


async def save(path: str | None = None) -> dict:
    """Salva o desenho (SAVEAS se path for informado)."""
    return _r(await (await _b()).drawing_save(path=path))


async def export_dxf(path: str) -> dict:
    """Exporta o desenho atual para DXF."""
    return _r(await (await _b()).drawing_save_as_dxf(path))


async def plot_pdf(path: str) -> dict:
    """Plota o desenho em PDF."""
    return _r(await (await _b()).drawing_plot_pdf(path))


async def drawing_setup(unidades: int = 6, escala_cota: float = 1.0) -> dict:
    """Ajusta unidades e escala de cota do desenho ATUAL (chame após new_drawing).

    unidades: 6 = metros (padrão). Sem isso o DXF sai com INSUNITS=mm (4).
    escala_cota: vira o DIMSCALE. O estilo tem DIMTXT=2,5, então o texto da cota
    mede 2,5 * escala_cota metros. Para planta em metros use 0,1 (texto 0,25).
    Define também TEXTSIZE 0,2, que é a altura padrão de texto novo.
    """
    return _r(await (await _b()).drawing_setup(unidades=unidades, escala_cota=escala_cota))


async def render_png(path: str | None = None) -> dict:
    """Gera PNG do desenho (visualização)."""
    b = await _b()
    r = await b.get_screenshot()
    if not _r(r).get("ok"):
        return _r(r)
    data = (r.payload or {}).get("data")
    if isinstance(data, (bytes, bytearray)):
        destino = path or os.path.join(tempfile.gettempdir(), "cad_render.png")
        Path(destino).write_bytes(data)
        return {"ok": True, "path": destino, "bytes": len(data)}
    return {"ok": True, "payload": r.payload}


async def screenshot(path: str | None = None) -> dict:
    """Captura a janela do CAD (mesmo que render_png no modo headless)."""
    return await render_png(path)


# ------------------------------------------------------------- undo / view
async def undo() -> dict:
    """Desfaz a última operação."""
    return _r(await (await _b()).undo())


async def redo() -> dict:
    """Refaz a última operação desfeita."""
    return _r(await (await _b()).redo())


async def zoom_extents() -> dict:
    """Zoom para os limites do desenho."""
    return _r(await (await _b()).zoom_extents())


# ------------------------------------------------------------- desenho
async def draw_line(x1: float, y1: float, x2: float, y2: float, layer: str | None = None) -> dict:
    """Desenha uma linha."""
    return _r(await (await _b()).create_line(x1, y1, x2, y2, layer=layer))


async def draw_rectangle(x1: float, y1: float, x2: float, y2: float, layer: str | None = None) -> dict:
    """Desenha um retângulo (polyline fechada)."""
    return _r(await (await _b()).create_rectangle(x1, y1, x2, y2, layer=layer))


async def draw_polyline(points: list[list[float]], closed: bool = False, layer: str | None = None) -> dict:
    """Desenha uma polyline pelos pontos [[x,y], ...]."""
    return _r(await (await _b()).create_polyline(points, closed=closed, layer=layer))


async def draw_circle(cx: float, cy: float, radius: float, layer: str | None = None) -> dict:
    """Desenha um círculo."""
    return _r(await (await _b()).create_circle(cx, cy, radius, layer=layer))


async def draw_arc(cx: float, cy: float, radius: float, start_angle: float, end_angle: float, layer: str | None = None) -> dict:
    """Desenha um arco (abertura de porta, por exemplo)."""
    return _r(await (await _b()).create_arc(cx, cy, radius, start_angle, end_angle, layer=layer))


async def draw_text(x: float, y: float, text: str, height: float = 2.5, rotation: float = 0.0, layer: str | None = None) -> dict:
    """Escreve um texto simples."""
    return _r(await (await _b()).create_text(x, y, text, height=height, rotation=rotation, layer=layer))


async def draw_mtext(x: float, y: float, width: float, text: str, height: float = 2.5, layer: str | None = None) -> dict:
    """Escreve um texto multilinha."""
    return _r(await (await _b()).create_mtext(x, y, width, text, height=height, layer=layer))


async def draw_hatch(entity_id: str, pattern: str = "ANSI31") -> dict:
    """Hachura uma entidade fechada (recebe o handle dela)."""
    return _r(await (await _b()).create_hatch(entity_id, pattern=pattern))


async def dim_linear(x1: float, y1: float, x2: float, y2: float, dim_x: float, dim_y: float) -> dict:
    """Cota linear entre dois pontos, com a linha de cota em (dim_x, dim_y)."""
    return _r(await (await _b()).create_dimension_linear(x1, y1, x2, y2, dim_x, dim_y))


async def dim_aligned(x1: float, y1: float, x2: float, y2: float, offset: float) -> dict:
    """Cota alinhada entre dois pontos, com afastamento."""
    return _r(await (await _b()).create_dimension_aligned(x1, y1, x2, y2, offset))


# ------------------------------------------------------------- camadas
async def layer_create(name: str, color: int | str = 7, linetype: str = "CONTINUOUS") -> dict:
    """Cria uma camada."""
    return _r(await (await _b()).layer_create(name, color=color, linetype=linetype))


async def layer_set_current(name: str) -> dict:
    """Define a camada corrente."""
    return _r(await (await _b()).layer_set_current(name))


async def ensure_standard_layers() -> dict:
    """Cria o conjunto padrão de camadas (PAREDES, PORTAS, JANELAS, COTAS, TEXTOS, HACHURA...)."""
    return await _ensure_layers(await _b())


# ------------------------------------------------------------- blocos
async def block_insert(name: str, x: float, y: float, scale: float = 1.0, rotation: float = 0.0) -> dict:
    """Insere um bloco."""
    return _r(await (await _b()).block_insert(name, x, y, scale=scale, rotation=rotation))


async def block_attributes(entity_id: str) -> dict:
    """Lê os atributos de um bloco inserido (largura de porta, tipo de janela...)."""
    return _r(await (await _b()).block_get_attributes(entity_id))


async def block_set_attribute(entity_id: str, tag: str, value: str) -> dict:
    """Altera um atributo de bloco."""
    return _r(await (await _b()).block_update_attribute(entity_id, tag, value))


# ------------------------------------------------------------- nossos extras
async def desenhar_ambiente(
    nome: str,
    x: float,
    y: float,
    largura: float,
    altura: float,
    com_hachura: bool = True,
    com_texto: bool = True,
    altura_texto: float = 0.18,
    padrao_hachura: str = "ANSI31",
) -> dict:
    """Desenha um ambiente como contorno fechado em PAREDES + hachura + texto com nome e área.

    Retorna handle, área e perímetro — a base do quantitativo e da EAP por ambiente.
    """
    b = await _b()
    area = round(largura * altura, 3)
    per = round(2 * (largura + altura), 3)
    cont = await b.create_rectangle(x, y, x + largura, y + altura, layer="PAREDES")
    if not cont.ok:
        return {"ok": False, "erro": cont.error or "falha ao desenhar contorno"}

    saida = {"ok": True, "ambiente": nome, "area": area, "perimetro": per,
             "contorno": cont.payload, "hachura": None, "texto": None}

    if com_hachura:
        handle = (cont.payload or {}).get("handle")
        if handle:
            h = await b.create_hatch(handle, pattern=padrao_hachura)
            saida["hachura"] = _r(h)

    if com_texto:
        rotulo = f"{nome}\\P{area:,.2f} m²".replace(",", "X").replace(".", ",").replace("X", ".")
        t = await b.create_text(x + largura / 2, y + altura / 2, rotulo,
                                height=altura_texto, layer="TEXTOS")
        saida["texto"] = _r(t)
    return saida


async def quantitativo(layer: str | None = None) -> dict:
    """Lê o desenho atual e devolve quantitativos por camada (comprimentos, áreas, blocos, textos, cotas).

    Funciona nos dois motores: o AutoCAD exporta um DXF temporário e a análise roda nele.
    """
    b = await _b()
    tmp = os.path.join(tempfile.gettempdir(), "cad_mcp_quantitativo.dxf")
    exp = await b.drawing_save_as_dxf(tmp)
    if not exp.ok:
        return {"ok": False, "erro": exp.error or "não foi possível exportar DXF para análise"}
    dados = analisar(tmp)
    dados["ok"] = True
    dados["backend"] = b.name
    if layer:
        for chave in ("entidades_por_camada", "comprimento_por_camada", "area_fechada_por_camada"):
            dados[chave] = {k: v for k, v in dados[chave].items() if k == layer}
    return dados


TOOLS = [
    cad_status,
    inspect_drawing, query_entities, erase, erase_filter, move_entity, layer_list, block_list, quantitativo,
    command_line, script, cancel,
    new_drawing, open, save, export_dxf, plot_pdf, drawing_setup, render_png, screenshot,
    undo, redo, zoom_extents,
    draw_line, draw_rectangle, draw_polyline, draw_circle, draw_arc,
    draw_text, draw_mtext, draw_hatch, dim_linear, dim_aligned,
    layer_create, layer_set_current, ensure_standard_layers,
    block_insert, block_attributes, block_set_attribute,
    desenhar_ambiente,
]

# --------------------------------------------------------------- vocabulario
# Nome PUBLICO da ferramenta: padrao `verbo_objeto` do autocad-mcp-pro 1.6.0
# (entity_*, drawing_*, view_*, dimension_*, layer_*, block_*, system_*, arch_*).
# Adotado para que um prompt escrito para aquele servidor funcione aqui sem
# traducao. A funcao Python mantem o nome antigo: nada de codigo quebra.
# Sem equivalente do outro lado, o nome fica como esta (quantitativo, script).
NOMES = {
    "cad_status": "system_status",
    "inspect_drawing": "drawing_info",
    "query_entities": "entity_list",
    "erase": "entity_erase",
    "erase_filter": "entity_erase_filter",
    "move_entity": "entity_move",
    "layer_list": "layer_list",
    "block_list": "block_list",
    "quantitativo": "quantitativo",
    "command_line": "system_run_command",
    "script": "script",
    "cancel": "cancel",
    "new_drawing": "drawing_new",
    "open": "drawing_open",
    "save": "drawing_save",
    "export_dxf": "drawing_export_dxf",
    "plot_pdf": "drawing_export_pdf",
    "render_png": "view_render_png",
    "screenshot": "view_screenshot",
    "undo": "drawing_undo",
    "redo": "drawing_redo",
    "zoom_extents": "view_zoom_extents",
    "draw_line": "entity_create_line",
    "draw_rectangle": "entity_create_rectangle",
    "draw_polyline": "entity_create_polyline",
    "draw_circle": "entity_create_circle",
    "draw_arc": "entity_create_arc",
    "draw_text": "entity_create_text",
    "draw_mtext": "entity_create_mtext",
    "draw_hatch": "entity_create_hatch",
    "dim_linear": "dimension_linear",
    "dim_aligned": "dimension_aligned",
    "layer_create": "layer_create",
    "layer_set_current": "layer_set_current",
    "ensure_standard_layers": "drawing_apply_iso_layers",
    "block_insert": "block_insert",
    "block_attributes": "block_get_attributes",
    "block_set_attribute": "block_set_attributes",
    "desenhar_ambiente": "arch_room",
}


def nome_publico(fn) -> str:
    """Nome exposto no MCP. Cai para o nome da funcao se nao mapeado."""
    return NOMES.get(getattr(fn, "__name__", str(fn)), getattr(fn, "__name__", str(fn)))


_publicos = [nome_publico(t) for t in TOOLS]
if len(set(_publicos)) != len(_publicos):
    from collections import Counter
    _dup = [n for n, c in Counter(_publicos).items() if c > 1]
    raise RuntimeError("nome publico duplicado em tools.NOMES: %s" % _dup)
