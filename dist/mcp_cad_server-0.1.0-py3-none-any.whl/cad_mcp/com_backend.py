# -*- coding: utf-8 -*-
"""Backend AutoCAD via COM/ActiveX — o motor "vivo" principal do mcp-cad-server.

Por que COM e nao PostMessage/arquivo?
    O truque de injetar WM_CHAR no MDIClient depende do layout da janela de
    linha de comando (que no AutoCAD 2025 nem e' filha do MDIClient) e rouba
    foco. `Document.SendCommand` faz o mesmo pelo canal oficial de automacao:
      - nao rouba foco (funciona com o AutoCAD minimizado);
      - nao depende de versao nem do LT;
      - `PlotToFile` resolve o PDF nativamente.

Licoes aprendidas (custaram caro, ficam registradas):
  1. NUNCA usar `(load "arquivo.lsp")`: o SECURELOAD do AutoCAD abre um
     dialogo modal "Security - Unsigned Executable File" e o dialogo modal
     bloqueia TODAS as chamadas COM (RPC_E_CALL_REJECTED). Por isso o codigo
     LISP vai INLINE, montado como string e rodado com `(eval (read ...))`.
  2. `SendCommand` e' assincrono e a linha de comando aceita strings longas
     (testado com >500 chars), mas o texto TEM que terminar com "\n",
     senao o AutoCAD fica esperando Enter e passa a rejeitar o COM.
  3. AutoCAD rejeita chamadas COM de vez em quando enquanto esta ocupado
     (`RPC_E_CALL_REJECTED`). Todo acesso passa por `_chamar`, que tenta de
     novo com backoff e, se preciso, manda um ESC para limpar o prompt.
  4. `Application.Documents` as vezes volta sem type-info (binding tardio);
     o caminho confiavel e' `Application.ActiveDocument`.
  5. Para achar o desenho atual, `ActiveDocument.ModelSpace.Count` funciona
     sempre; `Documents.Count` nao.

Nada e' escrito no perfil do usuario: nem acaddoc.lsp, nem SECURELOAD,
nem TRUSTEDPATHS. Os temporarios ficam em %MCP_CAD_TEMP% (padrao
C:/temp/mcp_cad_com, sem espacos).
"""
from __future__ import annotations

import os
import sys
import tempfile
import threading
import time
import uuid
from pathlib import Path

_SRC = Path(__file__).resolve().parents[1]
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from autocad_mcp.backends.base import (  # noqa: E402
    AutoCADBackend,
    BackendCapabilities,
    CommandResult,
)

from .sexp import parse as sexp_parse  # noqa: E402

# --------------------------------------------------------------- constantes COM
AC_EXTENTS = 1
AC_SCALE_TO_FIT = 0
PLOTTER_PDF = "DWG To PDF.pc3"

# candidatos de FileType para DXF no SaveAs (mudam entre versoes; testamos)
DXF_SAVEAS_TYPES = (65, 61, 33, 29, 25, 21, 17, 13, 1)

PROGIDS = ("AutoCAD.Application.25", "AutoCAD.Application.24", "AutoCAD.Application")

# HRESULTs de "servidor ocupado" -> vale tentar de novo
BUSY = (-2147418111, -2147417846, -2147417847)
TENTATIVAS = int(os.environ.get("MCP_CAD_COM_TENTATIVAS", "40"))


def _q(s) -> str:
    """Escapa uma string Python para virar literal AutoLISP."""
    return str(s).replace("\\", "/").replace('"', '\\"')


def _uma_linha(texto: str) -> str:
    """Normaliza o codigo LISP para UMA linha, sem mexer dentro de strings.

    `SendCommand` interpreta "\\n" como Enter, entao quebra de linha no meio de
    um `progn` vira prompt de continuacao (ruido). Espaco dentro de literal e'
    permitido; fora dele colapsamos para um unico espaco.
    """
    saida = []
    dentro = False
    escape = False
    pendente = False
    for c in texto:
        if dentro:
            if escape:
                saida.append(c)
                escape = False
                continue
            if c == "\\":
                saida.append(c)
                escape = True
                continue
            if c == '"':
                saida.append(c)
                dentro = False
                continue
            saida.append(" " if c in "\r\n\t" else c)
            continue
        if c in " \t\r\n":
            pendente = True
            continue
        if c == ";":
            # estamos numa linha unica: um comentario comeria o resto do programa
            return "".join(saida)
        if c == '"':
            if pendente and saida:
                saida.append(" ")
            pendente = False
            saida.append(c)
            dentro = True
            continue
        if pendente and saida:
            saida.append(" ")
        pendente = False
        saida.append(c)
    return "".join(saida)


def _com_erro(e: Exception) -> str:
    txt = str(e)
    low = txt.lower()
    if "rejeitada" in low or "rejected" in low:
        return "AutoCAD ocupado (RPC_E_CALL_REJECTED): %s" % txt
    return txt


class ComBackend(AutoCADBackend):
    """Backend que conversa com um AutoCAD JA ABERTO pelo canal COM."""

    name = "autocad_com"

    def __init__(self) -> None:
        self._app = None
        self._doc = None
        self._tid: int | None = None
        base = os.environ.get("MCP_CAD_TEMP") or "C:/temp/mcp_cad_com"
        self._raiz = Path(base)
        try:
            self._raiz.mkdir(parents=True, exist_ok=True)
        except Exception:
            self._raiz = Path(tempfile.gettempdir()) / "mcp_cad_com"
            self._raiz.mkdir(parents=True, exist_ok=True)
        self._contador = 0

    # ------------------------------------------------------------- propriedades
    @property
    def capabilities(self) -> BackendCapabilities:
        return BackendCapabilities(
            can_read_drawing=True,
            can_modify_entities=True,
            can_create_entities=True,
            can_screenshot=True,
            can_save=True,
            can_plot_pdf=True,
            can_zoom=True,
            can_query_entities=True,
            can_file_operations=True,
            can_undo=True,
        )

    # ---------------------------------------------------------------- retry/COM
    def _esc(self) -> None:
        """Manda ESC para o AutoCAD limpar um prompt pendente (sem roubar foco)."""
        try:
            from . import win32_bridge

            h = win32_bridge.find_autocad_window()
            if h:
                win32_bridge.enviar_esc(h)
        except Exception:
            pass

    def _chamar(self, fn, *a, **kw):
        """Executa um acesso COM tolerando 'AutoCAD ocupado'."""
        atraso = 0.2
        ultimo = None
        for i in range(TENTATIVAS):
            try:
                return fn(*a, **kw)
            except Exception as e:
                ultimo = e
                code = getattr(e, "hresult", None)
                if code not in BUSY:
                    raise
                if i and i % 8 == 0:
                    self._esc()
                time.sleep(atraso)
                atraso = min(atraso * 1.3, 1.5)
        raise RuntimeError("AutoCAD recusou a chamada COM %d vezes: %s" % (TENTATIVAS, _com_erro(ultimo)))

    def _coinit(self) -> None:
        """pywin32/COM exige CoInitialize por thread."""
        tid = threading.get_ident()
        if self._tid != tid:
            try:
                import pythoncom

                pythoncom.CoInitialize()
            except Exception:
                pass
            self._tid = tid
            self._app = None
            self._doc = None

    def _conectar(self, tentativas: int | None = None) -> None:
        self._coinit()
        if self._app is not None and self._doc is not None:
            try:
                self._chamar(lambda: self._doc.Name)
                return
            except Exception:
                self._app = self._doc = None

        import win32com.client as wc

        ultimo = None
        for progid in PROGIDS:
            try:
                self._app = self._chamar(wc.GetActiveObject, progid)
                break
            except Exception as e:
                ultimo = e
                self._app = None
        if self._app is None:
            raise RuntimeError(
                "AutoCAD nao exposto via COM (GetActiveObject falhou). "
                "Abra o AutoCAD normalmente e tente de novo. Ultimo erro: %s" % _com_erro(ultimo)
            )
        self._doc = self._chamar(lambda: self._app.ActiveDocument)
        if self._doc is None:
            raise RuntimeError("AutoCAD sem documento ativo (nenhum desenho aberto).")

    def _d(self):
        self._conectar()
        return self._doc

    # -------------------------------------------------------------- primitivas
    def _send(self, texto: str) -> None:
        """Manda texto para a linha de comando (garante o Enter no fim)."""
        doc = self._d()
        if not texto.endswith("\n"):
            texto += "\n"
        self._chamar(doc.SendCommand, texto)

    def _novo_arquivo(self, prefixo: str, ext: str) -> Path:
        self._contador += 1
        return self._raiz / ("%s_%03d_%s.%s" % (prefixo, self._contador, uuid.uuid4().hex[:6], ext))

    def _eval_lines(self, expr: str, timeout: float = 30.0) -> tuple[bool, list[str], str | None]:
        """Roda `expr` no AutoCAD (INLINE, sem `load`) e devolve as linhas de saida."""
        res = self._novo_arquivo("out", "txt")
        res_posix = str(res).replace("\\", "/")
        linha = _uma_linha(expr)
        programa = (
            '(progn (setq __mcp_r (vl-catch-all-apply (quote (lambda () %s))))'
            ' (setq __mcp_f (open "%s" "w"))'
            ' (if (vl-catch-all-error-p __mcp_r)'
            '  (progn (write-line "MCPERR" __mcp_f)'
            '         (write-line (vl-catch-all-error-message __mcp_r) __mcp_f))'
            '  (write-line (vl-prin1-to-string __mcp_r) __mcp_f))'
            ' (close __mcp_f) (princ))'
        ) % (linha, res_posix)
        self._send(programa)

        t0 = time.time()
        while time.time() - t0 < timeout:
            if res.exists():
                time.sleep(0.05)
                try:
                    linhas = res.read_text(encoding="utf-8", errors="replace").splitlines()
                except Exception:
                    linhas = []
                if linhas and linhas[0] == "MCPERR":
                    return False, linhas, (linhas[1] if len(linhas) > 1 else "erro LISP")
                return True, linhas, None
            time.sleep(0.04)
        return False, [], "timeout de %.1fs (AutoCAD sem executar o SendCommand)" % timeout

    def _eval(self, expr: str, timeout: float = 30.0):
        ok, linhas, erro = self._eval_lines(expr, timeout)
        if not ok:
            raise RuntimeError(erro)
        if not linhas:
            return None
        return sexp_parse(linhas[0])

    def _aval(self, expr: str, timeout: float = 30.0) -> CommandResult:
        try:
            return CommandResult(ok=True, payload=self._eval(expr, timeout))
        except Exception as e:
            return CommandResult(ok=False, error=str(e))

    # ------------------------------------------------------------------ ciclo
    async def initialize(self) -> CommandResult:
        try:
            self._conectar()
            doc = self._d()
            info = {"backend": self.name, "documento": self._chamar(lambda: doc.Name)}
            try:
                info["aplicacao"] = self._chamar(lambda: self._app.Name)
                info["versao"] = self._chamar(lambda: self._app.Version)
            except Exception:
                pass
            # ambiente previsivel para desenhar/cotar (NAO mexe em SECURELOAD)
            for var, val in (("CMDECHO", 0), ("OSMODE", 0), ("ATTDIA", 0), ("MIRRTEXT", 0)):
                try:
                    self._chamar(doc.SetVariable, var, val)
                except Exception:
                    pass
            return CommandResult(ok=True, payload=info)
        except Exception as e:
            return CommandResult(ok=False, error=_com_erro(e))

    async def status(self) -> CommandResult:
        try:
            self._conectar()
            return CommandResult(
                ok=True,
                payload={
                    "backend": self.name,
                    "documento": self._chamar(lambda: self._doc.Name),
                    "pronto": True,
                },
            )
        except Exception as e:
            return CommandResult(ok=False, error=_com_erro(e))

    # ------------------------------------------------------------ desenho (info)
    async def drawing_info(self) -> CommandResult:
        expr = (
            '(progn (setq __d (vla-get-ActiveDocument (vlax-get-acad-object)))'
            ' (list (cons (quote nome) (vla-get-Name __d))'
            ' (cons (quote caminho) (vla-get-FullName __d))'
            ' (cons (quote salvo) (if (= (vla-get-Saved __d) :vlax-true) 1 0))'
            ' (cons (quote entidades) (vla-get-Count (vla-get-ModelSpace __d)))'
            ' (cons (quote camadas) (vla-get-Count (vla-get-Layers __d)))'
            ' (cons (quote layouts) (vla-get-Count (vla-get-Layouts __d)))'
            ' (cons (quote limites) (list (getvar "LIMMIN") (getvar "LIMMAX")))'
            ' (cons (quote unidade) (getvar "INSUNITS"))))'
        )
        return self._aval(expr)

    async def drawing_get_variables(self, names: list[str] | None = None) -> CommandResult:
        if not names:
            names = ["DIMSCALE", "DIMTXT", "DIMASZ", "CLAYER", "LTSCALE", "INSUNITS", "MEASUREMENT", "TEXTSIZE"]
        pares = " ".join('(cons "%s" (getvar "%s"))' % (n, n) for n in names)
        return self._aval("(list %s)" % pares)

    async def entity_count(self, layer: str | None = None) -> CommandResult:
        if layer:
            expr = '(sslength (ssget "_X" (list (cons 8 "%s"))))' % _q(layer)
        else:
            expr = '(vla-get-Count (vla-get-ModelSpace (vla-get-ActiveDocument (vlax-get-acad-object))))'
        return self._aval(expr)

    async def layer_list(self) -> CommandResult:
        expr = (
            '(progn (vl-load-com) (setq __d (vla-get-ActiveDocument (vlax-get-acad-object)))'
            ' (setq __out "")'
            ' (vlax-for __l (vla-get-Layers __d)'
            '   (setq __out (strcat __out (vla-get-Name __l) "|"'
            '     (itoa (vla-get-Color __l)) "|" (vla-get-Linetype __l) "|"'
            '     (if (= (vla-get-LayerOn __l) :vlax-true) "1" "0") "|"'
            '     (if (= (vla-get-Freeze __l) :vlax-true) "1" "0") "|"'
            '     (if (= (vla-get-Lock __l) :vlax-true) "1" "0") "|"'
            '     (if (= (vla-get-Plottable __l) :vlax-true) "1" "0") "\\n")))'
            ' __out)'
        )
        try:
            bruto = self._eval(expr)
        except Exception as e:
            return CommandResult(ok=False, error=str(e))
        camadas = []
        if isinstance(bruto, str):
            for linha in bruto.split("\n"):
                p = linha.split("|")
                if len(p) >= 7:
                    camadas.append({
                        "nome": p[0],
                        "cor": int(p[1]) if p[1].lstrip("-").isdigit() else p[1],
                        "linetype": p[2],
                        "ligada": p[3] == "1",
                        "congelada": p[4] == "1",
                        "travada": p[5] == "1",
                        "plota": p[6] == "1",
                    })
        return CommandResult(ok=True, payload=camadas)

    async def block_list(self) -> CommandResult:
        return CommandResult(ok=True, payload=[])

    # -------------------------------------------------------------- arquivo
    async def drawing_create(self, name: str | None = None) -> CommandResult:
        try:
            self._conectar()
            novo = self._chamar(self._app.Documents.Add)
            self._doc = novo
            if name:
                try:
                    self._chamar(novo.SaveAs, str(Path(name)).replace("\\", "/"))
                except Exception:
                    pass
            return CommandResult(ok=True, payload={"documento": self._chamar(lambda: novo.Name)})
        except Exception as e:
            return CommandResult(ok=False, error=_com_erro(e))

    async def drawing_setup(self, unidades: int = 6, escala_cota: float = 1.0) -> CommandResult:
        """Ajusta o desenho novo para trabalhar em METROS (INSUNITS=6).

        Sem isso o DXF sai com INSUNITS=mm e o quantitativo interpreta errado.
        """
        return self._aval(
            '(progn (setvar "INSUNITS" %d) (setvar "MEASUREMENT" 1)'
            ' (setvar "LUNITS" 2) (setvar "LUPREC" 2) (setvar "AUNITS" 0)'
            ' (setvar "DIMSCALE" %s) (setvar "TEXTSIZE" 0.2)'
            ' (setvar "DIMDEC" 2) (setvar "DIMZIN" 0) (setvar "DIMTAD" 1)'
            ' (setvar "DIMASZ" 1.0) (setvar "DIMEXE" 0.6) (setvar "DIMEXO" 0.4)'
            ' (setvar "LTSCALE" 1.0) (setvar "PSLTSCALE" 1)'
            ' (setvar "PDMODE" 0) (setvar "MIRRTEXT" 0) (setvar "ATTDIA" 0) T)'
            % (unidades, escala_cota)
        )

    async def drawing_open(self, path: str) -> CommandResult:
        try:
            self._conectar()
            p = str(Path(path)).replace("\\", "/")
            d = self._chamar(self._app.Documents.Open, p)
            self._doc = d
            return CommandResult(ok=True, payload={"documento": self._chamar(lambda: d.Name), "caminho": p})
        except Exception as e:
            return CommandResult(ok=False, error=_com_erro(e))

    async def drawing_save(self, path: str | None = None) -> CommandResult:
        try:
            doc = self._d()
            if path:
                alvo = Path(path)
                alvo.parent.mkdir(parents=True, exist_ok=True)
                # o SaveAs do AutoCAD reclama se o arquivo ja' existe em alguns casos
                if alvo.exists():
                    try:
                        alvo.unlink()
                    except Exception:
                        pass
                self._chamar(doc.SaveAs, str(alvo).replace("\\", "/"))
                return CommandResult(ok=True, payload={"salvo_em": str(alvo), "bytes": alvo.stat().st_size if alvo.exists() else None})
            if not self._chamar(lambda: doc.FullName):
                return CommandResult(ok=False, error="desenho novo sem caminho: informe 'path'")
            self._chamar(doc.Save)
            return CommandResult(ok=True, payload={"salvo_em": self._chamar(lambda: doc.FullName)})
        except Exception as e:
            return CommandResult(ok=False, error=_com_erro(e))

    def _estagio_sem_espaco(self, sufixo: str) -> Path:
        return self._raiz / ("stage_%s_%s%s" % (uuid.uuid4().hex[:8], time.strftime("%H%M%S"), sufixo))

    async def drawing_save_as_dxf(self, path: str) -> CommandResult:
        """Exporta o desenho atual para DXF.

        Rota preferida: salvar em DWG e converter com o `accoreconsole.exe`
        (headless, sem dialogo, sem renomear o desenho da sessao).
        Fallback: `-WBLOCK` / `SaveAs` dentro da sessao aberta.
        """
        destino = Path(path)
        try:
            destino.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
        if destino.exists():
            try:
                destino.unlink()
            except Exception:
                pass

        # 1) accoreconsole: precisa de um DWG em disco
        try:
            from . import accore

            if accore.disponivel():
                doc = self._d()
                atual = self._chamar(lambda: doc.FullName)
                if not atual:
                    atual = str(self._estagio_sem_espaco(".dwg"))
                    self._chamar(doc.SaveAs, str(atual).replace("\\", "/"))
                r = accore.dwg_para_dxf(atual, destino)
                if r.get("ok"):
                    r["rota"] = "accoreconsole"
                    r["origem_dwg"] = atual
                    return CommandResult(ok=True, payload=r)
                ultimo = r.get("erro") or "accoreconsole falhou"
            else:
                ultimo = "accoreconsole indisponivel"
        except Exception as e:
            ultimo = _com_erro(e)

        # 2) rota interna: -WBLOCK (sem dialogo)
        estagio = self._estagio_sem_espaco(".dxf")
        if estagio.exists():
            estagio.unlink()
        posix = str(estagio).replace("\\", "/")
        try:
            doc = self._d()
            self._chamar(doc.SetVariable, "FILEDIA", 0)
            self._send('_.-WBLOCK "%s" * ' % posix)
            t0 = time.time()
            while time.time() - t0 < 45:
                if estagio.exists() and estagio.stat().st_size > 200:
                    destino.write_bytes(estagio.read_bytes())
                    return CommandResult(
                        ok=True,
                        payload={"dxf": str(destino), "bytes": destino.stat().st_size, "rota": "-WBLOCK"},
                    )
                time.sleep(0.2)
            ultimo = "-WBLOCK nao gerou arquivo"
        except Exception as e:
            ultimo = _com_erro(e)

        # 3) sem mais rotas destrutivas: `SaveAs` renomearia o desenho da sessao
        #    do usuario, entao preferimos devolver o erro.
        return CommandResult(
            ok=False,
            error="nao consegui exportar DXF (accoreconsole e -WBLOCK falharam: %s)" % ultimo,
        )

    async def drawing_purge(self) -> CommandResult:
        return self._aval('(progn (command "_.-PURGE" "_A" "*" "_N") T)')

    # -------------------------------------------------------------------- PDF
    async def drawing_plot_pdf(self, path: str, media: str | None = None) -> CommandResult:
        """Plota o layout atual para PDF usando o plotter 'DWG To PDF.pc3'.

        `media` (ex. "A3") forca um tamanho de folha; sem ele a preferencia e A4.
        """
        destino = Path(path)
        try:
            destino.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
        if destino.exists():
            try:
                antigo_mtime = destino.stat().st_mtime
            except Exception:
                antigo_mtime = None
            try:
                destino.unlink()
                removido = True
            except Exception:
                removido = False
        else:
            antigo_mtime = None
            removido = True
        posix = str(destino).replace("\\", "/")
        try:
            doc = self._d()
            try:
                self._chamar(doc.SetVariable, "BACKGROUNDPLOT", 0)
            except Exception:
                pass
            lay = self._chamar(lambda: doc.ActiveLayout)
            try:
                self._chamar(setattr, lay, "ConfigName", PLOTTER_PDF)
                self._chamar(lay.RefreshPlotDeviceInfo)
            except Exception:
                pass
            try:
                medias = list(self._chamar(lay.GetCanonicalMediaNames))
                if media:
                    pref = [n for n in medias if media.upper() in n.upper()]
                else:
                    pref = [n for n in medias if "A4" in n.upper()] or [n for n in medias if "A3" in n.upper()]
                if pref:
                    self._chamar(setattr, lay, "CanonicalMediaName", pref[0])
            except Exception:
                pass
            for attr, val in (
                ("PlotType", AC_EXTENTS),
                ("CenterPlot", True),
                ("PlotRotation", 0),
                ("StandardScale", AC_SCALE_TO_FIT),
                ("PlotWithPlotStyles", True),
                ("PlotHidden", False),
                ("PlotViewportBorders", False),
            ):
                try:
                    self._chamar(setattr, lay, attr, val)
                except Exception:
                    pass
            pl = self._chamar(lambda: doc.Plot)
            try:
                self._chamar(setattr, pl, "QuietErrorMode", True)
            except Exception:
                pass
            ok = self._chamar(pl.PlotToFile, posix, PLOTTER_PDF)
            t0 = time.time()
            while time.time() - t0 < 90:
                if destino.exists() and destino.stat().st_size > 500:
                    st = destino.stat()
                    # So vale se o arquivo foi realmente regravado: unlink bem-sucedido
                    # ou mtime novo. Sem isso, um PDF travado no Acrobat fazia o plot
                    # devolver ok reaproveitando o arquivo velho (armadilha 16).
                    novo = removido or (antigo_mtime is not None and st.st_mtime > antigo_mtime + 0.001)
                    if novo:
                        return CommandResult(
                            ok=True,
                            payload={"pdf": str(destino), "bytes": st.st_size, "retorno": bool(ok)},
                        )
                time.sleep(0.25)
            return CommandResult(
                ok=False,
                error="PlotToFile executou mas o PDF nao foi regravado "
                      "(arquivo aberto/travado no visualizador?)",
            )
        except Exception as e:
            return CommandResult(ok=False, error=_com_erro(e))

    # ------------------------------------------------------------- undo / view
    async def undo(self) -> CommandResult:
        return self._aval('(progn (command "_.U") T)')

    async def redo(self) -> CommandResult:
        return self._aval('(progn (command "_.REDO") T)')

    async def zoom_extents(self) -> CommandResult:
        return self._aval('(progn (command "_.ZOOM" "_E") T)')

    async def zoom_window(self, x1: float, y1: float, x2: float, y2: float) -> CommandResult:
        return self._aval(
            '(progn (command "_.ZOOM" "_W" (list %s %s 0.0) (list %s %s 0.0)) T)' % (x1, y1, x2, y2)
        )

    # ------------------------------------------------------------ LISP livre
    async def execute_lisp(self, code: str) -> CommandResult:
        return self._aval("(progn %s T)" % code)

    # -------------------------------------------------------------- entidades
    @staticmethod
    def _handle(expr_corpo: str) -> str:
        """Cria a entidade e devolve o HANDLE (estavel entre sessoes/saves)."""
        return '(progn (entmakex %s) (cdr (assoc 5 (entget (entlast)))))' % expr_corpo

    async def entmakex(self, corpo: str) -> CommandResult:
        """Cria uma entidade a partir de uma lista DXF ja montada. Devolve o HANDLE.

        Baixo nivel, usado pelo renderizador de plantas (`planta.py`): o corpo ja
        vem como expressao LISP, ex. `(list (cons 0 "LINE") ...)`.
        """
        return self._aval(self._handle(corpo))

    async def create_line(self, x1: float, y1: float, x2: float, y2: float, layer: str | None = None) -> CommandResult:
        lay = _q(layer or "0")
        corpo = (
            '(list (cons 0 "LINE") (cons 100 "AcDbEntity") (cons 8 "%s")'
            ' (cons 100 "AcDbLine") (cons 10 (list %s %s 0.0)) (cons 11 (list %s %s 0.0)))'
            % (lay, x1, y1, x2, y2)
        )
        return self._aval(self._handle(corpo))

    async def create_rectangle(self, x1: float, y1: float, x2: float, y2: float, layer: str | None = None) -> CommandResult:
        lay = _q(layer or "0")
        pts = [(x1, y1), (x2, y1), (x2, y2), (x1, y2)]
        cons10 = "".join(" (cons 10 (list %s %s))" % (p[0], p[1]) for p in pts)
        corpo = (
            '(list (cons 0 "LWPOLYLINE") (cons 100 "AcDbEntity") (cons 8 "%s")'
            ' (cons 100 "AcDbPolyline") (cons 90 4) (cons 70 1)%s)' % (lay, cons10)
        )
        return self._aval(self._handle(corpo))

    async def create_polyline(self, points, closed: bool = False, layer: str | None = None) -> CommandResult:
        lay = _q(layer or "0")
        cons10 = "".join(" (cons 10 (list %s %s))" % (p[0], p[1]) for p in points)
        corpo = (
            '(list (cons 0 "LWPOLYLINE") (cons 100 "AcDbEntity") (cons 8 "%s")'
            ' (cons 100 "AcDbPolyline") (cons 90 %d) (cons 70 %d)%s)'
            % (lay, len(points), 1 if closed else 0, cons10)
        )
        return self._aval(self._handle(corpo))

    async def create_circle(self, cx: float, cy: float, radius: float, layer: str | None = None) -> CommandResult:
        lay = _q(layer or "0")
        corpo = (
            '(list (cons 0 "CIRCLE") (cons 100 "AcDbEntity") (cons 8 "%s")'
            ' (cons 100 "AcDbCircle") (cons 10 (list %s %s 0.0)) (cons 40 %s))' % (lay, cx, cy, radius)
        )
        return self._aval(self._handle(corpo))

    async def create_arc(self, cx: float, cy: float, radius: float, start_angle: float, end_angle: float, layer: str | None = None) -> CommandResult:
        # entmake/entget do AutoLISP usam RADIANOS nos grupos 50/51 (ver tests/probe_arco4.py)
        lay = _q(layer or "0")
        corpo = (
            '(list (cons 0 "ARC") (cons 100 "AcDbEntity") (cons 8 "%s")'
            ' (cons 100 "AcDbCircle") (cons 10 (list %s %s 0.0)) (cons 40 %s)'
            ' (cons 100 "AcDbArc") (cons 50 (angtof "%s")) (cons 51 (angtof "%s")))'
            % (lay, cx, cy, radius, start_angle, end_angle)
        )
        return self._aval(self._handle(corpo))

    async def create_text(self, x: float, y: float, text: str, height: float = 2.5, rotation: float = 0.0, layer: str | None = None) -> CommandResult:
        lay = _q(layer or "0")
        corpo = (
            '(list (cons 0 "TEXT") (cons 100 "AcDbEntity") (cons 8 "%s")'
            ' (cons 100 "AcDbText") (cons 10 (list %s %s 0.0)) (cons 40 %s) (cons 1 "%s")'
            ' (cons 50 (angtof "%s")))'
            % (lay, x, y, height, _q(text), rotation)
        )
        return self._aval(self._handle(corpo))

    async def create_mtext(self, x: float, y: float, width: float, text: str, height: float = 2.5, layer: str | None = None) -> CommandResult:
        lay = _q(layer or "0")
        corpo = (
            '(list (cons 0 "MTEXT") (cons 100 "AcDbEntity") (cons 8 "%s")'
            ' (cons 100 "AcDbMText") (cons 10 (list %s %s 0.0)) (cons 40 %s) (cons 41 %s) (cons 1 "%s"))'
            % (lay, x, y, height, width, _q(text))
        )
        return self._aval(self._handle(corpo))

    async def create_hatch(self, entity_id: str, pattern: str = "ANSI31") -> CommandResult:
        """Hachura uma entidade fechada (por handle)."""
        expr = (
            '(progn (setq __e (handent "%s"))'
            ' (if __e (progn (command "_.-HATCH" "_P" "%s" "1" "0" "_S" __e "" "") T) nil))'
            % (_q(entity_id), _q(pattern))
        )
        return self._aval(expr)

    async def entity_list(self, layer: str | None = None, tipo: str | None = None) -> CommandResult:
        conds = []
        if layer:
            conds.append('(= (strcase (vla-get-Layer __e)) (strcase "%s"))' % _q(layer))
        if tipo:
            conds.append('(= (cdr (assoc 0 (entget (vlax-vla-object->ename __e)))) "%s")' % _q(tipo))
        if len(conds) > 1:
            cond = "(and " + " ".join(conds) + ")"
        elif conds:
            cond = conds[0]
        else:
            cond = "T"
        expr = (
            '(progn (vl-load-com) (setq __d (vla-get-ActiveDocument (vlax-get-acad-object)))'
            ' (setq __out "")'
            ' (vlax-for __e (vla-get-ModelSpace __d)'
            '  (if %s'
            '   (setq __out (strcat __out (vla-get-Handle __e) "|" (vla-get-ObjectName __e) "|"'
            '     (vla-get-Layer __e) "|"'
            '     (cdr (assoc 0 (entget (vlax-vla-object->ename __e)))) "\\n"))))'
            ' __out)' % cond
        )
        try:
            bruto = self._eval(expr)
        except Exception as e:
            return CommandResult(ok=False, error=str(e))
        itens = []
        if isinstance(bruto, str):
            for linha in bruto.split("\n"):
                p = linha.split("|")
                if len(p) >= 4 and p[0]:
                    itens.append({"handle": p[0], "tipo": p[3], "objeto": p[1], "camada": p[2]})
        return CommandResult(ok=True, payload=itens)

    async def entity_erase_filter(self, layer: str | None = None, tipo: str | None = None,
                                  texto: str | None = None, confirmar: bool = False) -> CommandResult:
        """Apaga em bloco por camada/tipo/conteudo. Sem nenhum filtro, recusa."""
        filtros = []
        if layer:
            filtros.append('(cons 8 "%s")' % _q(layer))
        if tipo:
            filtros.append('(cons 0 "%s")' % _q(tipo))
        if texto:
            filtros.append('(cons 1 "%s")' % _q(texto))
        if not filtros:
            return CommandResult(ok=False, error="informe ao menos um filtro (layer, tipo ou texto)")
        lst = "(list %s)" % " ".join(filtros)
        if confirmar:
            expr = ('(progn (setq __s (ssget "_X" %s))'
                    ' (if __s (progn (setq __n (sslength __s) __i 0)'
                    '   (repeat __n (entdel (ssname __s __i)) (setq __i (1+ __i))) __n) 0))' % lst)
        else:
            expr = '(progn (setq __s (ssget "_X" %s)) (if __s (sslength __s) 0))' % lst
        return self._aval(expr)

    async def entity_get(self, entity_id: str) -> CommandResult:
        expr = (
            '(progn (setq __e (handent "%s"))'
            ' (if __e (list (cons (quote handle) "%s")'
            '   (cons (quote tipo) (cdr (assoc 0 (entget __e))))'
            '   (cons (quote camada) (cdr (assoc 8 (entget __e))))'
            '   (cons (quote dxf) (vl-princ-to-string (entget __e)))) nil))'
            % (_q(entity_id), _q(entity_id))
        )
        return self._aval(expr)

    async def entity_erase(self, entity_id: str) -> CommandResult:
        return self._aval('(progn (setq __e (handent "%s")) (if __e (progn (entdel __e) 1) 0))'
                          % _q(entity_id))

    async def entity_move(self, entity_id: str, dx: float, dy: float) -> CommandResult:
        expr = (
            '(progn (setq __e (handent "%s"))'
            ' (if __e (command "_.MOVE" __e "" (list 0 0) (list %s %s)) nil) T)' % (_q(entity_id), dx, dy)
        )
        return self._aval(expr)

    async def entity_copy(self, entity_id: str, dx: float, dy: float) -> CommandResult:
        expr = (
            '(progn (setq __e (handent "%s"))'
            ' (if __e (command "_.COPY" __e "" (list 0 0) (list %s %s)) nil) T)' % (_q(entity_id), dx, dy)
        )
        return self._aval(expr)

    # -------------------------------------------------------------- camadas
    async def layer_create(self, name: str, color: str | int = 7, linetype: str = "CONTINUOUS") -> CommandResult:
        try:
            cor = int(color)
        except Exception:
            mapa = {"red": 1, "yellow": 2, "green": 3, "cyan": 4, "blue": 5, "magenta": 6, "white": 7}
            cor = mapa.get(str(color).lower(), 7)
        expr = (
            '(progn (if (not (tblsearch "LAYER" "%s"))'
            ' (entmakex (list (cons 0 "LAYER") (cons 100 "AcDbSymbolTableRecord")'
            '   (cons 100 "AcDbLayerTableRecord") (cons 2 "%s") (cons 70 0) (cons 62 %s) (cons 6 "%s"))))'
            ' (if (tblsearch "LAYER" "%s") 1 0))' % (_q(name), _q(name), cor, _q(linetype), _q(name))
        )
        return self._aval(expr)

    async def layer_set_current(self, name: str) -> CommandResult:
        return self._aval('(progn (setvar "CLAYER" "%s") T)' % _q(name))

    async def layer_set_properties(self, name: str, color=None, linetype=None, lineweight=None) -> CommandResult:
        pedacos = []
        if color is not None:
            try:
                cor = int(color)
            except Exception:
                mapa = {"red": 1, "yellow": 2, "green": 3, "cyan": 4, "blue": 5, "magenta": 6, "white": 7}
                cor = mapa.get(str(color).lower(), 7)
            pedacos.append('(command "_.-LAYER" "_C" "%s" "%s" "")' % (cor, _q(name)))
        if linetype:
            pedacos.append('(command "_.-LAYER" "_L" "%s" "%s" "")' % (_q(linetype), _q(name)))
        if lineweight:
            pedacos.append('(command "_.-LAYER" "_LW" "%s" "%s" "")' % (_q(lineweight), _q(name)))
        if not pedacos:
            return CommandResult(ok=True, payload={"no-op": name})
        return self._aval("(progn %s T)" % " ".join(pedacos))

    # ---------------------------------------------------------------- blocos
    async def block_insert(self, name: str, x: float, y: float, scale: float = 1.0, rotation: float = 0.0, block_id: str | None = None) -> CommandResult:
        expr = (
            '(progn (entmakex (list (cons 0 "INSERT") (cons 100 "AcDbEntity") (cons 8 "0")'
            ' (cons 100 "AcDbBlockReference") (cons 2 "%s") (cons 10 (list %s %s 0.0))'
            ' (cons 41 %s) (cons 42 %s) (cons 43 %s) (cons 50 (angtof "%s"))))'
            ' (cdr (assoc 5 (entget (entlast)))))' % (_q(name), x, y, scale, scale, scale, rotation)
        )
        return self._aval(expr)

    # ------------------------------------------------------------ cotas/texto
    async def create_dimension_linear(self, x1: float, y1: float, x2: float, y2: float, dim_x: float, dim_y: float) -> CommandResult:
        expr = (
            '(progn (setvar "CMDECHO" 0) (setvar "OSMODE" 0)'
            ' (command "_.DIMLINEAR" "_non" (list %s %s 0.0) "_non" (list %s %s 0.0) "_non" (list %s %s 0.0))'
            ' (if (entlast) (cdr (assoc 5 (entget (entlast)))) nil))'
            % (x1, y1, x2, y2, dim_x, dim_y)
        )
        return self._aval(expr)

    async def create_dimension_aligned(self, x1: float, y1: float, x2: float, y2: float, offset: float) -> CommandResult:
        mx, my = (x1 + x2) / 2.0, (y1 + y2) / 2.0
        dx, dy = x2 - x1, y2 - y1
        n = max((dx * dx + dy * dy) ** 0.5, 1e-9)
        ox, oy = mx - dy / n * offset, my + dx / n * offset
        expr = (
            '(progn (setvar "CMDECHO" 0) (setvar "OSMODE" 0)'
            ' (command "_.DIMALIGNED" "_non" (list %s %s 0.0) "_non" (list %s %s 0.0) "_non" (list %s %s 0.0))'
            ' (if (entlast) (cdr (assoc 5 (entget (entlast)))) nil))' % (x1, y1, x2, y2, ox, oy)
        )
        return self._aval(expr)

    # ----------------------------------------------------------- screenshot
    async def get_screenshot(self) -> CommandResult:
        try:
            from . import win32_bridge

            hwnd = win32_bridge.find_autocad_window()
            if not hwnd:
                return CommandResult(ok=False, error="janela do AutoCAD nao encontrada")
            from .screenshot_win import capturar

            return CommandResult(ok=True, payload={"png": str(capturar(hwnd, self._raiz))})
        except Exception as e:
            return CommandResult(ok=False, error=str(e))
